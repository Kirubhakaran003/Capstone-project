import React, { Component} from "react";

import axios from "axios";
import { useEffect, useState } from "react";
import { Badge, Button, Card, Col, Container, Form, Row } from "react-bootstrap";
import { useParams } from "react-router-dom";



type RouteParams = {
    id: string
}

interface TodoList {
    id: number,
    title: string,
    description: string,
    status: string
}


const Updatelist: React.FC<{}> = () => {


    const { id } = useParams<RouteParams>();
    const [todoTitle, setTodoTitle] = useState("");
    const [todoDescription, setTodoDescription] = useState("");
    const [todoCompleted, setTodoCompleted] = useState("");
    const [myTodoLists, setMyTodoLists] = useState<TodoList>();


    const searchFetchData = async () => {

        const response = await axios.get<TodoList>(
            "http://localhost:8080/api/todolist/" + id
        );
        setMyTodoLists(response.data);
        setTodoTitle(response.data['title']);
        setTodoDescription(response.data['description']);
        setTodoCompleted(response.data['status']);

    };
    const updateData = async () => {

        const newData = {
            "id": id,
            "title": todoTitle,
            "description": todoDescription,
            "status": todoCompleted
        };
        await axios.put("http://localhost:8080/api/todolist/" + id, newData);
        alert("Successfully Updated")


    };


    useEffect(() => {
        searchFetchData()
    }, [])



    return (

        <>
            <Container>
                <Row>
                    <Col md={12}>Update Department</Col>
                    <Col md={12}>
                        <Form style={{ width: "400px", marginLeft: "200px", marginTop: "50px" }} onSubmit={updateData}>
                            <br></br>
                            <Form.Group className="mb-3">
                                <Form.Label>Todo Title</Form.Label>
                                <Form.Control type="text" placeholder="Enter Todo list title" value={todoTitle} onChange={(e) => setTodoTitle(e.target.value)} />
                            </Form.Group>

                            <Form.Group className="mb-3">
                                <Form.Label>Todo Description</Form.Label>
                                <Form.Control type="text" placeholder="enter Todo list Description" value={todoDescription} onChange={(e) => setTodoDescription(e.target.value)} />
                            </Form.Group>

                           

                            <Button variant="primary" type="submit" >
                                Submit
                            </Button>
                        </Form>


                    </Col>
                </Row>
            </Container >
        </>
    )
}


export default Updatelist;
