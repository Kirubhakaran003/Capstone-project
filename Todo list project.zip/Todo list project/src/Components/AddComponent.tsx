import axios from "axios";
import React, { Component,useState,useRef } from "react";
import { Form, Button, Container, Col, Row } from "react-bootstrap";
import { useNavigate } from "react-router-dom";




const Addlist: React.FC<{}> = () => {

    const [json, setjson] = useState("http://localhost:8080/api/todolist");

    const [id, setId] = useState(0);
    const [todoTitle, setTodoTitle] = useState("");

    const [todoDescription, setTodoDescription] = useState("");
    const [todoCompleted, setTodoCompleted] = useState("");
    const nav=useNavigate();

    const addtodoData = async () => {
        const newItem = {
            "id": id,
            "title": todoTitle,
            "description": todoDescription,
            "status":todoCompleted
        };
        await axios.post("http://localhost:8080/api/todolist", newItem);
        alert("New Item Added");
        nav("/");
    }


    return (
        <>
            <Container>
                <Row>
                    <Col md={12}><h1> Add Todos</h1></Col>
                    <Col md={12}>
                        <Form style={{ width: "400px", marginLeft: "200px", marginTop: "50px" }} onSubmit={addtodoData}>
                            <br></br>
                            <Form.Group className="mb-3">
                                <Form.Label>Todo Title</Form.Label>
                                <Form.Control type="text" placeholder="Enter List name" onChange={(e) => setTodoTitle(e.target.value)} />
                            </Form.Group>

                            <Form.Group className="mb-3">
                                <Form.Label>Todo Description</Form.Label>
                                <Form.Control type="text" placeholder="List Description" onChange={(e) => setTodoDescription(e.target.value)} />
                            </Form.Group>
                            {/* <Form.Group className="mb-3">
                                <Form.Label>Todo Completed</Form.Label>
                                <Form.Control type="text" readOnly onChange={(e) => setTodoCompleted(e.target.value)} />
                            </Form.Group> */}

                            <Button variant="primary" type="submit" >
                                Submit
                            </Button>
                        </Form>

                    </Col>
                </Row>
            </Container>
        </>
    )
}
export default Addlist;