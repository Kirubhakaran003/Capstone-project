import React, { Component } from "react";

import axios from "axios";
import { useEffect, useState } from "react";
import { Badge, Button, Card, Col, Container, Form, Row } from "react-bootstrap";
import { useParams,useNavigate } from "react-router-dom";

type RouteParams = {
    id: string
}

interface TodoList {
    id: number,
    title: string,
    description: string,
    status: string
}


const Deletelist: React.FC<{}> = () => {


    const { id } = useParams<RouteParams>();
    const [myTodoList, setmyTodoLists] = useState<TodoList>();
    const nav =useNavigate();


    const searchFetchData = async () => {

        const response = await axios.get<TodoList>(
            "http://localhost:8080/api/todolist/" + id
        );
        setmyTodoLists(response.data);

    };
    const deleteData = async () => {
        await axios.delete("http://localhost:8080/api/todolist/" + id);
        alert("Todo List deleted");
        nav("/");

    };


    useEffect(() => {
        searchFetchData()
    }, [])



    return (

        <>
            <Container>
                <Row>
                    <Col md={12}>Delete Department</Col>
                    <Col md={12}>
                        Id :{myTodoList?.id}
                        <br /><br />
                        Todo title:{myTodoList?.title}
                        <br /><br />
                        Todo Descrition:{myTodoList?.description}
                        <br /><br />
                        Todo completed:{myTodoList?.status}
                        <br /><br />
                        <button className="btn btn-danger" onClick={deleteData} >Delete</button>
                    </Col>
                </Row>
            </Container>
        </>
    )
}


export default Deletelist;