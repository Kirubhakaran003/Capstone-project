import axios from "axios";
import { table } from "console";
import React, { Component, useEffect, useState } from "react";
import { Button, Card, Col, Container, Row } from "react-bootstrap";
import { Link } from "react-router-dom";
import { setConstantValue } from "typescript";


interface TodoList {
    id: number,
    title: string,
    description: string,
    status: string
}

const Showlist: React.FC<{}> = () => {
    const [todoData, setTodoData] = useState<TodoList[]>([]);
    const [todoCompleted, setTodoCompleted] = useState<TodoList>();


    const searchFetchData = async () => {

        const response = await axios.get<TodoList[]>(
            "http://localhost:8080/api/todolist"
        );
        setTodoData(response.data);

    };


    useEffect(() => {

        searchFetchData();
    }, [])

    const complete = async (id: number) => {

        await axios.put(`http://localhost:8080/api/todolist/updatestatus/${id}`, {
            status: "Yes",

        });
        searchFetchData();


    };
    const incomplete = async (id: number) => {

        await axios.put(`http://localhost:8080/api/todolist/updatestatus/${id}`, {
            status: "No",

        });
        searchFetchData();


    };


    return (
        <>
            <Container>
                <Row>
                <Col md={12} >  <br></br> <br></br>  </Col>
                    <Col md={12} >

                        <table className="table table-striped" border={3}>
                            <thead>
                                <tr>

                                    <th>Todo Title</th>
                                    <th>Todo Description</th>
                                    <th>Todo Completed</th>
                                    <th>Update</th>
                                    <th>Delete</th>

                                </tr>
                            </thead>
                            {todoData.map((temp) => (
                                <tbody>
                                    <tr key={temp.id}>

                                        <td>{temp.title}</td>
                                        <td>{temp.description}</td>
                                        <td>{temp.status}</td>
                                        <td> <Link className="btn btn-info" to={`/updateTodo/${temp.id}`}>Update</Link></td>
                                        <td> <Link className="btn btn-danger" to={`/deleteTodo/${temp.id}`}>Delete</Link></td>
                                        <td><button onClick={() => complete(temp.id)}>Complete</button></td>
                                        <td><button onClick={() => incomplete(temp.id)}>inComplete</button></td>

                                    </tr>
                                </tbody>

                            ))}

                        </table>
                    </Col>
                </Row>
            </Container>



        </>
    )
}

export default Showlist;