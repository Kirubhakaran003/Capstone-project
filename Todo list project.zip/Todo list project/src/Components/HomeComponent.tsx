import React from "react";
import { Component } from "react";
import ShowComponent from "./ShowComponent";
import { Link } from "react-router-dom";
import { link } from "fs";


class HomeComponent extends Component{

render(){
    return(
        <>
        <ShowComponent></ShowComponent>
        </>
    )
}


}
export default HomeComponent;