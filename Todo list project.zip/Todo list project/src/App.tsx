import React, { Suspense } from 'react';
import logo from './logo.svg';
import './App.css';
import { Container, Nav, Navbar } from 'react-bootstrap';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import HomeComponent from './Components/HomeComponent';
import AddComponent from './Components/AddComponent';
import UpdateComponent from './Components/UpdateComponent';
import DeleteComponent from './Components/DeleteComponent';

function App() {
  return (
    <>
      <Navbar bg="dark" data-bs-theme="dark">
        <Container>
          <Navbar.Brand href="/">To-Do List</Navbar.Brand>
          <Nav className="me-auto">
          <Nav.Link href="/">Home</Nav.Link>
          <Nav.Link href="/addTodoList">Add</Nav.Link>
          </Nav>
        </Container>
      </Navbar>

      <BrowserRouter basename='/'>
        <Suspense>
          <Routes>
          <Route path='/' element={<HomeComponent></HomeComponent>}></Route>
          <Route path='/addTodoList' element={<AddComponent></AddComponent>}></Route>
          <Route path='/updateTodo/:id' element={<UpdateComponent></UpdateComponent>}></Route>
          <Route path='/deleteTodo/:id' element={<DeleteComponent></DeleteComponent>}></Route>
          </Routes>
        </Suspense>
      </BrowserRouter>


    </>
  );
}

export default App;
